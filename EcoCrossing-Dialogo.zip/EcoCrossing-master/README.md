writeln("hla q puedo escribir acá omgggg");
