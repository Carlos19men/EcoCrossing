package Recuadros;
import java.awt.image.BufferedImage;

public class Recuadro {
    public BufferedImage imagen;
    public boolean colision = false;
    
    
}
