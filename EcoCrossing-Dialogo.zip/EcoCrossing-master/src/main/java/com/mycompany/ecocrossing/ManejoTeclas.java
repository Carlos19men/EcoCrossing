package com.mycompany.ecocrossing;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class ManejoTeclas implements KeyListener{
    public boolean arribaPresionado, abajoPresionado, izquierdaPresionado, derechaPresionado, interacturaObjetoPresionado, hablarNPCPresionado;
    PanelJuego panelJuego;

    // Depuración:
    boolean tiempo=false;
    
    public ManejoTeclas(PanelJuego panelJuego) {
        this.panelJuego= panelJuego;
    }
    
    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        //Obtener el codigo de la tecla presionada
        int codigo = e.getKeyCode();       
        
        // Estado Menú (Navega entre las pantallas del titulo):
        if(panelJuego.estadoJuego==panelJuego.estadoTitulo) {
            if(panelJuego.ui.estadoPantallaTitulo == 0) {
                estadoTitulo0(codigo);
            }
            else if(panelJuego.ui.estadoPantallaTitulo == 1) {
                estadoTitulo1(codigo);
            }
        }
        // Estado Jugando (Partida Activa):
        else if(panelJuego.estadoJuego==panelJuego.estadoJugando) {
            estadoJugando(codigo);
        }

        // Estado Pausa:
        else if(panelJuego.estadoJuego==panelJuego.estadoPausa) {
            estadoPausa(codigo);
        }
        
        // Estado de Personaje:
        else if(panelJuego.estadoJuego == panelJuego.estadoPersonaje) {
            estadoPersonaje(codigo);
        }
        
        //Estado de Dialogos
        else if(panelJuego.estadoJuego== panelJuego.estadoDialogo){
            estadoDialogo(codigo);
        }
            
    }

    public void estadoTitulo0(int codigo) {
        if(codigo == KeyEvent.VK_W || codigo == KeyEvent.VK_UP) {
            panelJuego.ui.comandoNumerico--;
            if(panelJuego.ui.comandoNumerico<0) {
                panelJuego.ui.comandoNumerico=2;
            }
        }
        
        else if(codigo == KeyEvent.VK_S || codigo == KeyEvent.VK_DOWN) {
            panelJuego.ui.comandoNumerico++;
            if(panelJuego.ui.comandoNumerico>2) {
                panelJuego.ui.comandoNumerico=0; 
            }
        }
        
        else if(codigo == KeyEvent.VK_ENTER) {
            if(panelJuego.ui.comandoNumerico == 0) {
                panelJuego.ui.estadoPantallaTitulo=1;
            }
            else if(panelJuego.ui.comandoNumerico == 1) {
                // Añadir Después:
            }
            else if(panelJuego.ui.comandoNumerico==2) {
                System.exit(0);
            }
        }
    }
    
    public void estadoTitulo1(int codigo) {
        if(codigo == KeyEvent.VK_W || codigo == KeyEvent.VK_UP) {
            panelJuego.ui.comandoNumerico--;
            if(panelJuego.ui.comandoNumerico<0) {
                panelJuego.ui.comandoNumerico=3;
            }
        }
                
        else if(codigo == KeyEvent.VK_S || codigo == KeyEvent.VK_DOWN) {
            panelJuego.ui.comandoNumerico++;
            if(panelJuego.ui.comandoNumerico>3) {
                panelJuego.ui.comandoNumerico=0; 
            }
        }
        else if(codigo == KeyEvent.VK_ENTER) {
            if(panelJuego.ui.comandoNumerico == 0) {
                // Implementar lógica para cargar una skin en específico, y luego arrancar el juego con ella...
                panelJuego.estadoJuego=panelJuego.estadoJugando;
                panelJuego.iniciarjuegoThread();
                panelJuego.jugador.ObtenerImagenSkin1();
                panelJuego.reproducirMusica(0);
            }
            else if(panelJuego.ui.comandoNumerico == 1) {
                // Implementar lógica para cargar una skin en específico, y luego arrancar el juego con ella...
                panelJuego.estadoJuego=panelJuego.estadoJugando;
                panelJuego.iniciarjuegoThread();
                panelJuego.jugador.ObtenerImagenSkin2();
                panelJuego.reproducirMusica(0);
            }

            else if(panelJuego.ui.comandoNumerico==2) {
                // Implementar lógica para cargar una skin en específico, y luego arrancar el juego con ella...
                panelJuego.estadoJuego=panelJuego.estadoJugando;
                panelJuego.iniciarjuegoThread();
                // panelJuego.jugador.ObtenerImagenSkin3();
                panelJuego.reproducirMusica(0);
            }

            else if(panelJuego.ui.comandoNumerico==3) {
                // En este caso volvemos al menú principal...
                panelJuego.ui.estadoPantallaTitulo=0;
            }
        }
    }
    
    public void estadoJugando(int codigo) {
        //Verificar a que direccion se refiere
        if(codigo == KeyEvent.VK_W || codigo == KeyEvent.VK_UP)
            arribaPresionado = true;
        else if(codigo == KeyEvent.VK_A || codigo == KeyEvent.VK_LEFT)
            izquierdaPresionado = true;
        else if(codigo == KeyEvent.VK_S || codigo == KeyEvent.VK_DOWN)
            abajoPresionado = true;
        else if(codigo == KeyEvent.VK_D || codigo == KeyEvent.VK_RIGHT)
            derechaPresionado = true;
        // Estado de pausa:
        else if(codigo == KeyEvent.VK_P || codigo == KeyEvent.VK_ESCAPE)
            panelJuego.estadoJuego= panelJuego.estadoPausa;
        
        // Verificar teclas especiales
        else if(codigo == KeyEvent.VK_R)
            interacturaObjetoPresionado = true;
        
        else if (codigo== KeyEvent.VK_Q)
                hablarNPCPresionado = true;
        
        // Estado personaje:
        else if(codigo == KeyEvent.VK_C) {
            panelJuego.estadoJuego= panelJuego.estadoPersonaje;
        }
        
        // Verificar depuración:
        else if(codigo == KeyEvent.VK_T) {
            tiempo = !tiempo;
        }
    }
    
    public void estadoPausa(int codigo) {
        if(codigo == KeyEvent.VK_P) {
            panelJuego.estadoJuego= panelJuego.estadoJugando;
        }
    }
    
    public void estadoPersonaje(int codigo) {
        if(codigo == KeyEvent.VK_C) {
            panelJuego.estadoJuego= panelJuego.estadoJugando;
        }
        if(codigo == KeyEvent.VK_W || codigo == KeyEvent.VK_UP) {
            if(panelJuego.ui.ranuraFila!=0) {
                panelJuego.ui.ranuraFila--;
                panelJuego.reproducirEfectosSonido(2);
            }
        }
            
        else if(codigo == KeyEvent.VK_A || codigo == KeyEvent.VK_LEFT) {
            if(panelJuego.ui.ranuraColumna!=0) {
                panelJuego.ui.ranuraColumna--;
                panelJuego.reproducirEfectosSonido(2);
            }
        }
        else if(codigo == KeyEvent.VK_S || codigo == KeyEvent.VK_DOWN) {
            if(panelJuego.ui.ranuraFila!=3) {
                panelJuego.ui.ranuraFila++;
                panelJuego.reproducirEfectosSonido(2);
            }
        }
            
        else if(codigo == KeyEvent.VK_D || codigo == KeyEvent.VK_RIGHT) {
            if(panelJuego.ui.ranuraColumna!=4) {
                panelJuego.ui.ranuraColumna++;
                panelJuego.reproducirEfectosSonido(2);
            }
        }
    }
    
    public void estadoDialogo(int codigo){
        if(codigo == KeyEvent.VK_SPACE)
            panelJuego.estadoJuego= panelJuego.estadoJugando;
    }
    
    @Override
    public void keyReleased(KeyEvent e) {
        //Obtener el codigo de la tecla que se solto
        int codigo = e.getKeyCode();  
        
        //Verificar a que direccion se refiere
        if(codigo == KeyEvent.VK_W || codigo == KeyEvent.VK_UP)
            arribaPresionado = false;
        if(codigo == KeyEvent.VK_A || codigo == KeyEvent.VK_LEFT)
            izquierdaPresionado = false;
        if(codigo == KeyEvent.VK_S || codigo == KeyEvent.VK_DOWN)
            abajoPresionado = false;
        if(codigo == KeyEvent.VK_D || codigo == KeyEvent.VK_RIGHT)
            derechaPresionado = false;
        
        //Verificar teclas especiales
        if(codigo == KeyEvent.VK_R)
            interacturaObjetoPresionado = false;
        
        if(codigo== KeyEvent.VK_Q)
                hablarNPCPresionado = false;
    }
    
}
