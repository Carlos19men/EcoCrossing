package Objeto;

import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author Maria Sandoval
 */
public class Papelera extends SuperObjeto{
    
    //Constructor
    public Papelera (){ //Sin parametros
        this.nombre ="papelera";
        colision=true;
        // Podriamos hacer ifs según el nombre para ver que descripción poner...
        descripcion="{"+nombre+"}\nPara botar basura";
    }
    
    //metodos 
    public void cargar(int escala){
        try{
            imagen= ImageIO.read(getClass().getResourceAsStream("/Objetos/Basura/papelera.png"));
            herramientaUtil.escalarImagen(imagen, escala, escala);
        }catch(IOException e){
            System.out.println("Error al cargar la imagen (Line 29)");
            e.printStackTrace();
        }
    }
}
